#if ! defined _PARSE_H
#define _PARSE_H

/* function prototype from parse.c */
absyn::Exp* parse(appel_string fname);


#endif
